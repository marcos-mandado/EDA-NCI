../EXECUTABLES/EDA-NCI.x<Na+_tweezer.inp
